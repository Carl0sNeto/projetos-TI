// Gerencia o carrinho no client (localStorage)
const CART_KEY = 'mini_loja_cart'
function readCart(){
  try{ return JSON.parse(localStorage.getItem(CART_KEY))||[] }catch(e){return[]}
}
function writeCart(c){ localStorage.setItem(CART_KEY, JSON.stringify(c)) }
function updateCount(){
  const c = readCart().reduce((s,i)=>s+i.qty,0)
  document.getElementById('cart-count').textContent = c
}
function formatBR(value){ return value.toFixed(2).replace('.',',') }

function renderCart(){
  const itemsEl = document.getElementById('cart-items')
  const cart = readCart()
  itemsEl.innerHTML = ''
  if(cart.length===0){ itemsEl.innerHTML = '<p>Seu carrinho está vazio.</p>'; document.getElementById('cart-total').textContent='0.00'; return }
  let total = 0
  cart.forEach(it=>{
    total += it.price*it.qty
    const div = document.createElement('div')
    div.className='cart-item'
    div.innerHTML = `<div class="meta"><strong>${it.name}</strong><div>R$ ${formatBR(it.price)} x ${it.qty}</div></div><div><button data-id="${it.id}" class="remove">Remover</button></div>`
    itemsEl.appendChild(div)
  })
  document.getElementById('cart-total').textContent = formatBR(total)
}

function addToCart(id,name,price){
  const cart = readCart()
  const found = cart.find(x=>x.id==id)
  if(found) found.qty++
  else cart.push({id:+id,name,price:+price,qty:1})
  writeCart(cart); updateCount()
}

document.addEventListener('click', e=>{
  if(e.target.classList.contains('add-btn')){
    addToCart(e.target.dataset.id,e.target.dataset.name,e.target.dataset.price)
  }
  if(e.target.id==='open-cart'){ document.getElementById('cart-modal').classList.remove('hidden'); renderCart() }
  if(e.target.id==='close-cart'){ document.getElementById('cart-modal').classList.add('hidden') }
  if(e.target.classList.contains('remove')){
    const id = e.target.dataset.id
    const cart = readCart().filter(x=>x.id!=id)
    writeCart(cart); renderCart(); updateCount()
  }
})

document.getElementById('checkout-form').addEventListener('submit', async function(e){
  e.preventDefault()
  const cart = readCart()
  if(cart.length===0){ alert('Carrinho vazio'); return }
  const form = new FormData(this)
  const payload = {name: form.get('name'), email: form.get('email'), cart}
  try{
    const res = await fetch('checkout.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})
    const data = await res.json()
    if(data.success){
      alert('Pedido recebido — ID: '+data.orderId)
      localStorage.removeItem(CART_KEY)
      updateCount(); document.getElementById('cart-modal').classList.add('hidden')
    } else alert('Erro no pedido')
  }catch(err){alert('Erro ao enviar pedido')}
})

// Inicialização
updateCount()
