Calculadora em C (Win32)

Arquivos:
- `calc_win32.c` — código fonte da calculadora usando API Win32.

Compilar (MinGW / gcc):

```sh
gcc calc_win32.c -o calc_win32.exe -mwindows
```

Uso:
- Rode `calc_win32.exe` para abrir a calculadora.