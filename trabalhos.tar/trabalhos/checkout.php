<?php
header('Content-Type: application/json; charset=utf-8');
$raw = file_get_contents('php://input');
if(!$raw){ echo json_encode(['success'=>false,'error'=>'no-data']); exit; }
$data = json_decode($raw, true);
if(!$data || !isset($data['name']) || !isset($data['email']) || !isset($data['cart'])){
  echo json_encode(['success'=>false,'error'=>'invalid']); exit;
}
$order = [
  'id' => time(),
  'name' => htmlspecialchars($data['name']),
  'email' => htmlspecialchars($data['email']),
  'items' => $data['cart'],
  'total' => array_reduce($data['cart'], function($s,$i){return $s + ($i['price'] * $i['qty']);}, 0)
];
$line = date('c')."\t".json_encode($order, JSON_UNESCAPED_UNICODE)."\n";
file_put_contents(__DIR__.DIRECTORY_SEPARATOR.'orders.txt', $line, FILE_APPEND | LOCK_EX);
echo json_encode(['success'=>true,'orderId'=>$order['id']]);
exit;
