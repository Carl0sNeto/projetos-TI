<?php
$products = [
	[
		'id' => 1,
		'name' => 'Camiseta Básica',
		'price' => 39.90,
		'desc' => '100% algodão, várias cores'
	],
	[
		'id' => 2,
		'name' => 'Caneca Estilosa',
		'price' => 24.50,
		'desc' => 'Cerâmica 320ml'
	],
	[
		'id' => 3,
		'name' => 'Boné Snapback',
		'price' => 59.00,
		'desc' => 'Ajustável, bordado'
	],
	[
		'id' => 4,
		'name' => 'Caderno A5',
		'price' => 19.90,
		'desc' => '80 folhas, capa dura'
	]
];
?>
<!doctype html>
<html lang="pt-BR">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Mini E-commerce</title>
		<link rel="stylesheet" href="css/styles.css">
	</head>
	<body>
		<header class="site-header">
			<h1>Minha Loja</h1>
			<button id="open-cart" class="cart-btn">Carrinho (<span id="cart-count">0</span>)</button>
		</header>

		<main class="product-grid">
			<?php foreach ($products as $p): ?>
			<article class="product-card">
				<h2><?=htmlspecialchars($p['name'])?></h2>
				<p class="desc"><?=htmlspecialchars($p['desc'])?></p>
				<p class="price">R$ <?=number_format($p['price'], 2, ',', '.')?></p>
				<button class="add-btn" data-id="<?=$p['id']?>" data-name="<?=htmlspecialchars($p['name'])?>" data-price="<?=$p['price']?>">Adicionar ao carrinho</button>
			</article>
			<?php endforeach; ?>
		</main>

		<div id="cart-modal" class="modal hidden">
			<div class="modal-content">
				<button id="close-cart" class="close">×</button>
				<h3>Seu Carrinho</h3>
				<div id="cart-items"></div>
				<div class="cart-footer">
					<div>Total: R$ <span id="cart-total">0.00</span></div>
					<form id="checkout-form">
						<input type="text" name="name" placeholder="Nome" required>
						<input type="email" name="email" placeholder="Email" required>
						<button type="submit" class="buy-btn">Finalizar Compra</button>
					</form>
				</div>
			</div>
		</div>

		<script src="js/app.js"></script>
	</body>
</html>
