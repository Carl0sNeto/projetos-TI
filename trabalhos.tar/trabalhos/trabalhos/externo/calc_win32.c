// Simple calculator GUI using Win32 API
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define IDC_DISPLAY 1000

// Button IDs: digits 0-9 and dot, ops, equals, clear
#define ID_BTN_0 2000
#define ID_BTN_1 2001
#define ID_BTN_2 2002
#define ID_BTN_3 2003
#define ID_BTN_4 2004
#define ID_BTN_5 2005
#define ID_BTN_6 2006
#define ID_BTN_7 2007
#define ID_BTN_8 2008
#define ID_BTN_9 2009
#define ID_BTN_DOT 2010
#define ID_BTN_ADD 2011
#define ID_BTN_SUB 2012
#define ID_BTN_MUL 2013
#define ID_BTN_DIV 2014
#define ID_BTN_EQ  2015
#define ID_BTN_C   2016
#define ID_BTN_BACK 2017
#define ID_BTN_SQRT 2018

static HWND hDisplay;
static char displayBuf[128] = "0";
static double savedValue = 0.0;
static char lastOp = 0; // '+', '-', '*', '/', 0 = none
static int entering = 0; // whether user is currently typing a number

void updateDisplay() {
    SetWindowTextA(hDisplay, displayBuf);
}

double toDouble(const char *s) { return atof(s); }

void fromDouble(double v, char *out, int outlen) {
    snprintf(out, outlen, "%g", v);
}

void doComputeOp(char op) {
    double val = toDouble(displayBuf);
    if (lastOp == 0) {
        savedValue = val;
    } else {
        if (lastOp == '+') savedValue = savedValue + val;
        else if (lastOp == '-') savedValue = savedValue - val;
        else if (lastOp == '*') savedValue = savedValue * val;
        else if (lastOp == '/') {
            if (val == 0.0) {
                strncpy(displayBuf, "Error", sizeof(displayBuf));
                updateDisplay();
                lastOp = 0; entering = 0;
                return;
            } else savedValue = savedValue / val;
        }
    }
    fromDouble(savedValue, displayBuf, sizeof(displayBuf));
    updateDisplay();
    lastOp = op;
    entering = 0;
}

void onDigit(int digit) {
    if (!entering || (strcmp(displayBuf, "0") == 0)) {
        snprintf(displayBuf, sizeof(displayBuf), "%d", digit);
        entering = 1;
    } else {
        size_t len = strlen(displayBuf);
        if (len + 2 < sizeof(displayBuf)) {
            displayBuf[len] = '0' + digit;
            displayBuf[len+1] = '\0';
        }
    }
    updateDisplay();
}

void onDot() {
    if (!entering) {
        strcpy(displayBuf, "0."); entering = 1;
    } else if (strchr(displayBuf, '.') == NULL) {
        size_t len = strlen(displayBuf);
        if (len + 2 < sizeof(displayBuf)) {
            displayBuf[len] = '.'; displayBuf[len+1] = '\0';
        }
    }
    updateDisplay();
}

void onClear() {
    // If there's a selection in the display, clear only the selected text.
    DWORD selStart = 0, selEnd = 0;
    SendMessageA(hDisplay, EM_GETSEL, (WPARAM)&selStart, (LPARAM)&selEnd);
    if (selStart != selEnd) {
        int len = (int)strlen(displayBuf);
        int s = (int)selStart;
        int e = (int)selEnd;
        if (s < 0) s = 0; if (e > len) e = len;
        if (s < e) {
            memmove(displayBuf + s, displayBuf + e, len - e + 1);
            if (displayBuf[0] == '\0') strcpy(displayBuf, "0");
            updateDisplay();
            return;
        }
    }
    // No selection: full reset
    strcpy(displayBuf, "0"); savedValue = 0.0; lastOp = 0; entering = 0; updateDisplay();
}

void onBackspace() {
    size_t len = strlen(displayBuf);
    if (len > 1) {
        displayBuf[len-1] = '\0';
    } else {
        strcpy(displayBuf, "0");
        entering = 0;
    }
    updateDisplay();
}

void onSqrt() {
    double val = toDouble(displayBuf);
    if (val < 0) {
        strcpy(displayBuf, "Error");
    } else {
        val = sqrt(val);
        fromDouble(val, displayBuf, sizeof(displayBuf));
    }
    updateDisplay();
    entering = 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (msg == WM_COMMAND) {
        int id = LOWORD(wParam);
        switch (id) {
            case ID_BTN_0: onDigit(0); break;
            case ID_BTN_1: onDigit(1); break;
            case ID_BTN_2: onDigit(2); break;
            case ID_BTN_3: onDigit(3); break;
            case ID_BTN_4: onDigit(4); break;
            case ID_BTN_5: onDigit(5); break;
            case ID_BTN_6: onDigit(6); break;
            case ID_BTN_7: onDigit(7); break;
            case ID_BTN_8: onDigit(8); break;
            case ID_BTN_9: onDigit(9); break;
            case ID_BTN_DOT: onDot(); break;
            case ID_BTN_C: onClear(); break;
            case ID_BTN_BACK: onBackspace(); break;
            case ID_BTN_SQRT: onSqrt(); break;
            case ID_BTN_ADD: doComputeOp('+'); break;
            case ID_BTN_SUB: doComputeOp('-'); break;
            case ID_BTN_MUL: doComputeOp('*'); break;
            case ID_BTN_DIV: doComputeOp('/'); break;
            case ID_BTN_EQ:
                // perform pending operation and clear it
                doComputeOp(0);
                lastOp = 0; entering = 0;
                break;
        }
    } else if (msg == WM_KEYDOWN) {
        int key = wParam;
        switch (key) {
            case '0': case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9':
                onDigit(key - '0');
                break;
            case VK_OEM_PERIOD:
            case '.':
                onDot();
                break;
            case '+':
            case VK_ADD:
                doComputeOp('+');
                break;
            case '-':
            case VK_SUBTRACT:
                doComputeOp('-');
                break;
            case '*':
            case VK_MULTIPLY:
                doComputeOp('*');
                break;
            case '/':
            case VK_DIVIDE:
                doComputeOp('/');
                break;
            case VK_RETURN:
                doComputeOp(0);
                lastOp = 0;
                entering = 0;
                break;
            case VK_BACK:
                onBackspace();
                break;
            case 'C':
            case 'c':
                onClear();
                break;
        }
        return 0;
    } else if (msg == WM_CREATE) {
        // create display
        hDisplay = CreateWindowExA(0, "EDIT", "0",
            WS_CHILD | WS_VISIBLE | WS_BORDER | ES_RIGHT | ES_READONLY,
            10, 10, 260, 30, hwnd, (HMENU)IDC_DISPLAY, GetModuleHandle(NULL), NULL);

        // create buttons (4 columns x 5 rows, but last row 3)
        const char *labels[] = {"7","8","9","/","4","5","6","*","1","2","3","-","0",".","=","+","C","<-","√"};
        int ids[] = {ID_BTN_7,ID_BTN_8,ID_BTN_9,ID_BTN_DIV,ID_BTN_4,ID_BTN_5,ID_BTN_6,ID_BTN_MUL,ID_BTN_1,ID_BTN_2,ID_BTN_3,ID_BTN_SUB,ID_BTN_0,ID_BTN_DOT,ID_BTN_EQ,ID_BTN_ADD,ID_BTN_C,ID_BTN_BACK,ID_BTN_SQRT};
        int x0 = 10, y0 = 50, w = 60, h = 40, gap = 10;
        for (int i = 0; i < 19; ++i) {
            int col = i % 4;
            int row = i / 4;
            int x = x0 + col * (w + gap);
            int y = y0 + row * (h + gap);
            CreateWindowA("BUTTON", labels[i], WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                          x, y, w, h, hwnd, (HMENU)ids[i], GetModuleHandle(NULL), NULL);
        }

    } else if (msg == WM_DESTROY) {
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcA(hwnd, msg, wParam, lParam);
}

int main(void) {
    const char *clsName = "CalcClass";
    WNDCLASSA wc = {0};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = GetModuleHandle(NULL);
    wc.lpszClassName = clsName;
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    RegisterClassA(&wc);

    HWND hwnd = CreateWindowExA(0, clsName, "Calculadora (C, Win32)",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, 300, 410,
        NULL, NULL, GetModuleHandle(NULL), NULL);
    if (!hwnd) return 1;
    ShowWindow(hwnd, SW_SHOW);

    MSG msg;
    while (GetMessageA(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageA(&msg);
    }
    return 0;
}