#include <stdio.h>

struct  cel {
    int conteudo;
    struct cel *prox;
};

typedef struct cel celula;

celula c;

int main() {
    c.conteudo = 100;
    printf("Conteudo: %d\n", c.conteudo);

    return 0;
}