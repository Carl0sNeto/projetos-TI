#include <stdio.h>
#include <locale.h>

int main() {
    //setlocale (LC_ALL, "");

    printf("Endereço\n");
    printf("Acentuação\n");
    printf("Título\n");
    printf("Qual é a Música?\n");
    return 0;
}