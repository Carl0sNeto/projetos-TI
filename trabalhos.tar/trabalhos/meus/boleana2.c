#include <stdio.h>

int main() {
    int a = 5, b = 3, x = 4, y = 4;

    if (((a + b) == (x + y)) && ((a * b) > (x * y)) || ((a - b) < (x - y))) {
        printf("A condição complexa é verdadeira!\n");
    } else {
        printf("A condição complexa é falsa!\n");
    }
    return 0;
}