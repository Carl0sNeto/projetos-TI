#include <stdio.h>

int main() {
    int inteiro = 42;
    float pontoFlutuante = 3.14f;
    double pontoFlutuanteMaior = 2.718281828459;
    char caractere = 'A';
    char string[] = "Olá, Mundo!";

    printf("Inteiro: %d\n", inteiro);
    printf("Float: %.2f\n", pontoFlutuante);
    printf("Double: %.12lf\n", pontoFlutuanteMaior);
    printf("Caractere: %c\n", caractere);
    printf("String: %s\n", string);

    return 0;
}