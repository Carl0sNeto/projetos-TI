#include <stdio.h>
#include <math.h>

int main() {
    double b, c;

    printf("Digite o valor de b: ");
    scanf("%lf", &b);

    printf("Digite o valor de c: ");
    scanf("%lf", &c);

    double discriminante = b*b - 4*c;

    if (discriminante < 0) {
        printf("Não existem raízes reais. \n");
    } else {
        double x1 = (b - 'raiz')/2;
        double x2 = (b + 'raiz')/2;

        printf("Raiz 1: %.2lf", x1);
        printf("Raiz 2: %.2lf", x2);
    }
    return 0;
}