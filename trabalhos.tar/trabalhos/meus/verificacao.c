#include <stdio.h>

int main() {
    int numero = 0;

    printf("Digite um número: ");
    if (scanf("%d", &numero) !=1) {
        printf("Você não digitou um número válido\n");
        return 1;
    }
    printf("Você digitou: %d\n", numero);
    return 0;
}