#include <stdio.h>

int main() {
    int a = 5, b = 3, x = 4, y = 4;

    if ((a + b) == (x = y)) {
        printf("As somas são iguais!\n");
    } else {
        printf("As somas são diferentes!\n");
    }
    return 0;
}