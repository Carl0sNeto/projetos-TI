#include <stdio.h>

void main() {
    int i;
    for (i = 1; i <=10; i = i +1) {
        printf("%d\n", i);}
    i = 20;
    while (i <= 25) {
        printf("i = %d\n", i);
        i++;}
    printf("Tchau.\n");
}