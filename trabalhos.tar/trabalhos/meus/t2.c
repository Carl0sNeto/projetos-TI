#include <stdio.h>

int salario;

int main() {
    scanf("%d", &salario);

    if (salario < 500) {
        printf("O salário reajustado será de %f\n", salario);
    } else {
        if (salario >= 500 && salario <= 1000) {
            printf("O salário reajustado será de %f\n", salario);
        } else {
            printf("O salário reajustado será de %f\n", salario);
        }
    }
    return 0;
}