#include <stdio.h>

int nota1,nota2,nota3,nota4,media;

int main() {
    printf("Digite a nota do primeiro bimestre:\n");
    scanf("%d:\n", &nota1);

    printf("Digite a nota do segundo bimestre:\n");
    scanf("%d:\n", &nota2);

    printf("Digite a nota do terceiro bimestre:\n");
    scanf("%d:\n", &nota3);

    printf("Digite a nota do quarto bimestre:\n");
    scanf("%d:\n", &nota4);

    media = (nota1 + nota2 + nota3 + nota4)/2;

    if (media >= 12) {
        printf("Você está aprovado!\n");
        printf("Média:%d", media);
    } else {
        printf("Você reprovou!\n");
        printf("Média:%d", media);
    }
    return 0;
}