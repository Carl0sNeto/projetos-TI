#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>

#define DICT_TABLE_SIZE 101
#define MAX_KEY_LEN 64
#define MAX_FIELD_LEN 64

typedef struct Person {
    char nome[MAX_FIELD_LEN];
    char cpf[MAX_FIELD_LEN];
    char telefone[MAX_FIELD_LEN];
    char profissao[MAX_FIELD_LEN];
} Person;

typedef struct Entry {
    char key[MAX_KEY_LEN];
    Person person;
    struct Entry *next;
} Entry;

static Entry *table[DICT_TABLE_SIZE];

static uint32_t fnv1a_hash(const char *s) {
    uint32_t h = 2166136261u;
    while (*s) {
        h ^= (unsigned char)*s++;
        h *= 16777619u;
    }
    return h;
}

static size_t dict_index(const char *key) {
    return fnv1a_hash(key) % DICT_TABLE_SIZE;
}

static void generate_key_from_cpf(const char *cpf, char *out, size_t out_size) {
    char digits[MAX_FIELD_LEN];
    size_t j = 0;

    for (size_t i = 0; cpf[i] != '\0' && j + 1 < sizeof(digits); ++i) {
        if (isdigit((unsigned char)cpf[i])) {
            digits[j++] = cpf[i];
        }
    }
    digits[j] = '\0';

    if (j == 0) {
        strncpy(out, cpf, out_size - 1);
        out[out_size - 1] = '\0';
        return;
    }

    uint32_t hash = fnv1a_hash(digits);
    snprintf(out, out_size, "cpf-%08X", hash);
}

static void dict_insert(const char *key,
                        const char *nome,
                        const char *cpf,
                        const char *telefone,
                        const char *profissao) {
    size_t index = dict_index(key);
    Entry *node = table[index];

    while (node) {
        if (strcmp(node->key, key) == 0) {
            strncpy(node->person.nome, nome, MAX_FIELD_LEN - 1);
            strncpy(node->person.cpf, cpf, MAX_FIELD_LEN - 1);
            strncpy(node->person.telefone, telefone, MAX_FIELD_LEN - 1);
            strncpy(node->person.profissao, profissao, MAX_FIELD_LEN - 1);
            node->person.nome[MAX_FIELD_LEN - 1] = '\0';
            node->person.cpf[MAX_FIELD_LEN - 1] = '\0';
            node->person.telefone[MAX_FIELD_LEN - 1] = '\0';
            node->person.profissao[MAX_FIELD_LEN - 1] = '\0';
            return;
        }
        node = node->next;
    }

    Entry *new_entry = malloc(sizeof(Entry));
    if (!new_entry) {
        fprintf(stderr, "Erro de memória ao inserir registro.\n");
        return;
    }

    strncpy(new_entry->key, key, MAX_KEY_LEN - 1);
    new_entry->key[MAX_KEY_LEN - 1] = '\0';

    strncpy(new_entry->person.nome, nome, MAX_FIELD_LEN - 1);
    new_entry->person.nome[MAX_FIELD_LEN - 1] = '\0';
    strncpy(new_entry->person.cpf, cpf, MAX_FIELD_LEN - 1);
    new_entry->person.cpf[MAX_FIELD_LEN - 1] = '\0';
    strncpy(new_entry->person.telefone, telefone, MAX_FIELD_LEN - 1);
    new_entry->person.telefone[MAX_FIELD_LEN - 1] = '\0';
    strncpy(new_entry->person.profissao, profissao, MAX_FIELD_LEN - 1);
    new_entry->person.profissao[MAX_FIELD_LEN - 1] = '\0';

    new_entry->next = table[index];
    table[index] = new_entry;
}

static Person *dict_search(const char *key) {
    size_t index = dict_index(key);
    Entry *node = table[index];
    while (node) {
        if (strcmp(node->key, key) == 0) {
            return &node->person;
        }
        node = node->next;
    }
    return NULL;
}

static int dict_remove(const char *key) {
    size_t index = dict_index(key);
    Entry *node = table[index];
    Entry *prev = NULL;

    while (node) {
        if (strcmp(node->key, key) == 0) {
            if (prev) {
                prev->next = node->next;
            } else {
                table[index] = node->next;
            }
            free(node);
            return 1;
        }
        prev = node;
        node = node->next;
    }
    return 0;
}

static void dict_free(void) {
    for (size_t i = 0; i < DICT_TABLE_SIZE; ++i) {
        Entry *node = table[i];
        while (node) {
            Entry *next = node->next;
            free(node);
            node = next;
        }
        table[i] = NULL;
    }
}

static void print_person(const Person *person) {
    if (!person) return;
    printf("Nome: %s\n", person->nome);
    printf("CPF: %s\n", person->cpf);
    printf("Telefone: %s\n", person->telefone);
    printf("Profissão: %s\n", person->profissao);
}

static void trim_newline(char *s) {
    size_t len = strlen(s);
    if (len > 0 && s[len - 1] == '\n') {
        s[len - 1] = '\0';
    }
}

int main(void) {
    char key[MAX_KEY_LEN];
    char nome[MAX_FIELD_LEN];
    char cpf[MAX_FIELD_LEN];
    char telefone[MAX_FIELD_LEN];
    char profissao[MAX_FIELD_LEN];
    char option[8];

    printf("Dicionário de pessoas (hash table)\n");
    printf("Pesquisa principal por CPF. A chave é gerada automaticamente a partir do CPF.\n\n");

    while (1) {
        printf("[1] Inserir  [2] Pesquisar  [3] Remover  [4] Sair\n");
        printf("Escolha: ");
        if (!fgets(option, sizeof option, stdin)) break;
        trim_newline(option);

        if (strcmp(option, "1") == 0) {
            printf("Nome: ");
            if (!fgets(nome, sizeof nome, stdin)) break;
            trim_newline(nome);

            printf("CPF: ");
            if (!fgets(cpf, sizeof cpf, stdin)) break;
            trim_newline(cpf);

            printf("Telefone: ");
            if (!fgets(telefone, sizeof telefone, stdin)) break;
            trim_newline(telefone);

            printf("Profissão: ");
            if (!fgets(profissao, sizeof profissao, stdin)) break;
            trim_newline(profissao);

            generate_key_from_cpf(cpf, key, sizeof key);
            dict_insert(key, nome, cpf, telefone, profissao);
            printf("Registro inserido/atualizado. Chave gerada: '%s'.\n\n", key);
        } else if (strcmp(option, "2") == 0) {
            printf("CPF: ");
            if (!fgets(cpf, sizeof cpf, stdin)) break;
            trim_newline(cpf);

            generate_key_from_cpf(cpf, key, sizeof key);
            Person *found = dict_search(key);
            if (found) {
                printf("Registro encontrado:\n");
                print_person(found);
            } else {
                printf("CPF '%s' não encontrado.\n", cpf);
            }
            printf("\n");
        } else if (strcmp(option, "3") == 0) {
            printf("CPF: ");
            if (!fgets(cpf, sizeof cpf, stdin)) break;
            trim_newline(cpf);

            generate_key_from_cpf(cpf, key, sizeof key);
            if (dict_remove(key)) {
                printf("Registro removido para CPF '%s'.\n\n", cpf);
            } else {
                printf("CPF '%s' não encontrado.\n\n", cpf);
            }
        } else if (strcmp(option, "4") == 0) {
            break;
        } else {
            printf("Opção inválida. Tente novamente.\n\n");
        }
    }

    dict_free();
    return 0;
}
