#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>

static uint32_t fnv1a_hash(const char *s) {
    uint32_t h = 2166136261u;
    while (*s) {
        h ^= (unsigned char)*s++;
        h *= 16777619u;
    }
    return h;
}

int main(void) {
    char line[128];
    if (printf("Digite o CPF: ") < 0) return 1;
    if (!fgets(line, sizeof line, stdin)) return 1;

    char digits[32];
    int di = 0;
    for (int i = 0; line[i] && di < 20; ++i) {
        if (isdigit((unsigned char)line[i])) digits[di++] = line[i];
    }
    digits[di] = '\0';
    if (di == 0) {
        printf("Nenhum dígito encontrado.\n");
        return 1;
    }

    uint32_t h = fnv1a_hash(digits);
    int two_digits = (int)(h % 100u); // 0..99
    printf("%02d\n", two_digits);
    return 0;
}
